const MODULE_ID = "wishbound-core";
const FLAG_KEY = "desire";
const FLAG_PATH = `flags.${MODULE_ID}.${FLAG_KEY}`;

export function registerDesireFeature() {
  Hooks.on("renderActorSheetV2", (app, element) => {
    const actor = app.actor;

    // Nur ProjectFU-Charaktere.
    if (game.system.id !== "projectfu") return;
    if (!actor || actor.type !== "character") return;

    // Sicherstellen, dass es wirklich das ProjectFU-Sheet ist.
    if (!element.classList.contains("projectfu")) return;

    // Desire bleibt wie besprochen Owner/GM-only.
    if (!actor.isOwner) return;

    injectNotesDesire(actor, element);
    injectOverviewDesire(actor, element);
  });
}

function getDesire(actor) {
  return String(actor.getFlag(MODULE_ID, FLAG_KEY) ?? "");
}

function injectNotesDesire(actor, element) {
  const notesTab = element.querySelector(
    '.tab[data-group="primary"][data-tab="notes"]'
  );

  if (!notesTab) return;
  if (notesTab.querySelector(".wishbound-desire-editor")) return;

  /*
   * In ProjectFU v4.16.2 ist das erste Section-Element
   * im Notes-Tab das actor-traits Partial:
   * Identity / Theme / Origin.
   */
  const traitsSection = notesTab.querySelector(
    "section.section-container.desc.grid-span-3.gap-5"
  );

  if (!traitsSection) return;

  const desireSection = document.createElement("section");
  desireSection.className =
    "section-container desc grid-span-3 gap-5 wishbound-desire-editor";

  const field = document.createElement("div");
  field.className = "traits resource-content wishbound-desire-field";

  const label = document.createElement("label");
  label.innerHTML = '<span class="resource-label-m">Desire</span>';

  const input = document.createElement("input");
  input.type = "text";
  input.name = FLAG_PATH;
  input.value = getDesire(actor);
  input.maxLength = 240;
  input.placeholder = "What does this character truly desire?";
  input.autocomplete = "off";

  field.append(label, input);
  desireSection.append(field);

  /*
   * Direkt NACH Identity / Theme / Origin
   * und damit VOR Bonds.
   */
  traitsSection.insertAdjacentElement("afterend", desireSection);

  // Overview live mitziehen, während geschrieben wird.
  input.addEventListener("input", () => {
    const display = element.querySelector(
      ".wishbound-desire-overview .wishbound-desire-value"
    );

    if (display) {
      display.textContent = input.value.trim() || "—";
    }
  });
}

function injectOverviewDesire(actor, element) {
  /*
   * "Overview" heißt in ProjectFU intern "stats".
   */
  const statsTab = element.querySelector(
    '.tab[data-group="primary"][data-tab="stats"]'
  );

  if (!statsTab) return;
  if (statsTab.querySelector(".wishbound-desire-overview")) return;

  /*
   * Das ist exakt der native Read-only-Block
   * Identity / Theme / Origin.
   */
  const traitsSection = statsTab.querySelector(
    "section.section-container.traits-container.desc"
  );

  if (!traitsSection) return;

  const desireSection = document.createElement("section");
  desireSection.className =
    "section-container traits-container desc wishbound-desire-overview";

  const field = document.createElement("div");
  field.className = "traits resource-content";

  const label = document.createElement("label");

  const title = document.createElement("span");
  title.className = "resource-label-l";
  title.textContent = "Desire:";

  const value = document.createElement("span");
  value.className = "resource-text-m wishbound-desire-value";
  value.textContent = getDesire(actor).trim() || "—";

  label.append(title, value);
  field.append(label);
  desireSection.append(field);

  /*
   * Direkt unter Identity / Theme / Origin.
   */
  traitsSection.insertAdjacentElement("afterend", desireSection);
}
import { registerDesireFeature } from "./features/desire.js";

Hooks.once("init", () => {
  console.log("Wishbound Core | Initializing");

  registerDesireFeature();
});